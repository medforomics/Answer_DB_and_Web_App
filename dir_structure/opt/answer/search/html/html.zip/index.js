
new Vue({
    el: '#app',
    data() {
        return {
        }
    },
    methods: {
        
    },
    created() {
    }
 
});

